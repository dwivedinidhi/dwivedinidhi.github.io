import { ExternalLink, Folder } from "lucide-react";
import { useInView } from "../hooks/useInView";

const projects = [
  {
    title: "Automated File Organizer",
    description:
      "A Python script that monitors a directory and automatically sorts files into categorized folders based on file type, reducing manual effort by 80%.",
    tech: ["Python", "OS Module", "Watchdog"],
    outcome: "Saved 5+ hours/week of manual file management across the team.",
    color: "from-primary/20 to-primary/5",
  },
  {
    title: "System Health Monitor",
    description:
      "Built a lightweight dashboard that tracks CPU, memory, and disk usage across multiple workstations, sending email alerts when thresholds are exceeded.",
    tech: ["Python", "psutil", "smtplib", "HTML/CSS"],
    outcome: "Proactively prevented 15+ system outages in the first quarter.",
    color: "from-[hsl(var(--glow-blue)/0.2)] to-[hsl(var(--glow-blue)/0.05)]",
  },
  {
    title: "IT Ticketing Automation Bot",
    description:
      "Developed a Python bot that parses incoming support emails, auto-categorizes tickets by priority, and assigns them to the appropriate support queue.",
    tech: ["Python", "IMAP", "Regex", "CSV"],
    outcome: "Reduced ticket triage time by 60% and improved response SLAs.",
    color: "from-primary/15 to-[hsl(var(--glow-blue)/0.1)]",
  },
];

const ProjectsSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="projects" className="section-padding relative">
      <div ref={ref} className="max-w-5xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold mb-2 text-center transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          Featured <span className="text-gradient">Projects</span>
        </h2>
        <p className={`text-muted-foreground text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          Some things I've built
        </p>
        <div className="grid md:grid-cols-3 gap-6">
          {projects.map((p, i) => (
            <div
              key={p.title}
              className={`group relative bg-card/80 backdrop-blur-sm border border-border rounded-2xl overflow-hidden flex flex-col transition-all duration-700 hover:border-primary/30 hover:-translate-y-1 hover:shadow-[0_20px_40px_-15px_hsl(var(--primary)/0.15)] ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${i * 150}ms` }}
            >
              {/* Gradient header */}
              <div className={`h-2 bg-gradient-to-r ${p.color}`} />
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-center justify-between mb-4">
                  <Folder className="text-primary" size={28} />
                  <ExternalLink size={16} className="text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <h3 className="text-lg font-semibold mb-3 group-hover:text-primary transition-colors">{p.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5 flex-1">
                  {p.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {p.tech.map((t) => (
                    <span
                      key={t}
                      className="text-xs font-mono px-2.5 py-1 rounded-full bg-primary/10 text-primary/80 border border-primary/10"
                    >
                      {t}
                    </span>
                  ))}
                </div>
                <div className="pt-4 border-t border-border">
                  <p className="text-xs text-primary font-medium flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                    {p.outcome}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
