import { useInView } from "../hooks/useInView";

const AboutSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="about" className="section-padding">
      <div ref={ref} className={`max-w-3xl mx-auto transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h2 className="text-3xl md:text-4xl font-bold mb-2 text-center">
          About <span className="text-gradient">Me</span>
        </h2>
        <div className="w-16 h-1 bg-primary mx-auto rounded-full mb-8" />
        <p className="text-muted-foreground leading-relaxed text-center text-lg">
          I'm a detail-oriented Python Developer and Desktop Support Engineer with a strong foundation in scripting, automation, and end-user technical support. I thrive on simplifying complex workflows through clean Python code and ensuring seamless IT operations. With hands-on experience across Windows and Linux environments, I combine programming proficiency with practical troubleshooting expertise to deliver reliable, efficient solutions. I'm passionate about continuous learning and leveraging technology to solve real-world problems.
        </p>
      </div>
    </section>
  );
};

export default AboutSection;
