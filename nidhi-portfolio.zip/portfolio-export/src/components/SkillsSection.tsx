import { Code, Monitor, Wrench } from "lucide-react";
import { useInView } from "../hooks/useInView";

const categories = [
  {
    icon: Code,
    title: "Programming",
    skills: [
      { name: "Python", level: 90 },
      { name: "Scripting", level: 85 },
      { name: "Automation", level: 80 },
      { name: "Data Processing", level: 75 },
    ],
  },
  {
    icon: Monitor,
    title: "Technical Skills",
    skills: [
      { name: "Windows Admin", level: 90 },
      { name: "Linux", level: 80 },
      { name: "Troubleshooting", level: 95 },
      { name: "Networking", level: 70 },
    ],
  },
  {
    icon: Wrench,
    title: "Tools & Platforms",
    skills: [
      { name: "Git & GitHub", level: 85 },
      { name: "VS Code", level: 90 },
      { name: "System Maintenance", level: 85 },
      { name: "Active Directory", level: 80 },
    ],
  },
];

const SkillsSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="skills" className="section-padding relative overflow-hidden">
      {/* Subtle grid bg */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(hsl(var(--primary)) 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

      <div ref={ref} className="max-w-5xl mx-auto relative z-10">
        <h2 className={`text-3xl md:text-4xl font-bold mb-2 text-center transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          My <span className="text-gradient">Skills</span>
        </h2>
        <p className={`text-muted-foreground text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          Technologies and tools I work with
        </p>
        <div className="grid md:grid-cols-3 gap-6">
          {categories.map((cat, i) => (
            <div
              key={cat.title}
              className={`group bg-card/80 backdrop-blur-sm border border-border rounded-2xl p-6 transition-all duration-700 hover:border-primary/30 hover:shadow-[0_0_30px_-10px_hsl(var(--primary)/0.2)] ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${i * 150}ms` }}
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                <cat.icon className="text-primary" size={24} />
              </div>
              <h3 className="text-lg font-semibold mb-5">{cat.title}</h3>
              <div className="space-y-4">
                {cat.skills.map((s) => (
                  <div key={s.name}>
                    <div className="flex justify-between text-sm mb-1.5">
                      <span className="text-muted-foreground">{s.name}</span>
                      <span className="text-primary font-mono text-xs">{s.level}%</span>
                    </div>
                    <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-primary to-[hsl(var(--glow-blue))] transition-all duration-1000 ease-out"
                        style={{ width: inView ? `${s.level}%` : '0%' }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
