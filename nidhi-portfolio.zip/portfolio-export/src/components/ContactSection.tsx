import { useState, FormEvent } from "react";
import { Mail, Linkedin, Send } from "lucide-react";
import { useInView } from "../hooks/useInView";
import { useToast } from "@/hooks/use-toast";

const ContactSection = () => {
  const { ref, inView } = useInView();
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email.trim()) e.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Invalid email";
    if (!form.message.trim()) e.message = "Message is required";
    return e;
  };

  const handleSubmit = (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length === 0) {
      toast({ title: "Message sent!", description: "Thank you for reaching out. I'll get back to you soon." });
      setForm({ name: "", email: "", message: "" });
    }
  };

  return (
    <section id="contact" className="section-padding">
      <div ref={ref} className="max-w-2xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold mb-2 text-center transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          Get in <span className="text-gradient">Touch</span>
        </h2>
        <div className="w-16 h-1 bg-primary mx-auto rounded-full mb-8" />

        <div className={`flex justify-center gap-6 mb-10 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <a href="mailto:nidhi@example.com" className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors text-sm">
            <Mail size={18} /> nidhi@example.com
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors text-sm">
            <Linkedin size={18} /> LinkedIn
          </a>
        </div>

        <form
          onSubmit={handleSubmit}
          className={`bg-card border border-border rounded-xl p-8 space-y-5 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          {(["name", "email", "message"] as const).map((field) => (
            <div key={field}>
              <label htmlFor={field} className="block text-sm font-medium mb-1.5 capitalize">
                {field}
              </label>
              {field === "message" ? (
                <textarea
                  id={field}
                  rows={4}
                  value={form[field]}
                  onChange={(e) => setForm({ ...form, [field]: e.target.value })}
                  className="w-full rounded-lg bg-secondary border border-border px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                  placeholder="Your message..."
                />
              ) : (
                <input
                  id={field}
                  type={field === "email" ? "email" : "text"}
                  value={form[field]}
                  onChange={(e) => setForm({ ...form, [field]: e.target.value })}
                  className="w-full rounded-lg bg-secondary border border-border px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  placeholder={field === "name" ? "Your name" : "you@email.com"}
                />
              )}
              {errors[field] && <p className="text-destructive text-xs mt-1">{errors[field]}</p>}
            </div>
          ))}
          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-semibold hover:brightness-110 transition-all glow-border"
          >
            <Send size={16} /> Send Message
          </button>
        </form>
      </div>
    </section>
  );
};

export default ContactSection;
