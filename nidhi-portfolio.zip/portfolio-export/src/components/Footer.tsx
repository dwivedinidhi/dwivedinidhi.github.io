import { Heart } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border py-8 px-4">
    <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
      <a href="#" className="text-xl font-bold text-gradient">ND</a>
      <p className="text-muted-foreground text-sm flex items-center gap-1.5">
        © {new Date().getFullYear()} Nidhi Dwivedi · Built with <Heart size={14} className="text-primary" /> and code
      </p>
      <div className="flex gap-6">
        {["About", "Projects", "Contact"].map((l) => (
          <a key={l} href={`#${l.toLowerCase()}`} className="text-muted-foreground hover:text-primary transition-colors text-sm">
            {l}
          </a>
        ))}
      </div>
    </div>
  </footer>
);

export default Footer;
