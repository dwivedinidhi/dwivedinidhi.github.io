import { ArrowDown } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => (
  <section className="min-h-screen flex items-center justify-center relative overflow-hidden section-padding pt-28">
    {/* Background image */}
    <img
      src={heroBg}
      alt=""
      className="absolute inset-0 w-full h-full object-cover opacity-30"
      width={1920}
      height={1080}
    />
    {/* Dark overlay */}
    <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />

    {/* Floating orbs */}
    <div className="absolute top-20 left-10 w-3 h-3 rounded-full bg-primary/60 animate-float" />
    <div className="absolute top-40 right-20 w-2 h-2 rounded-full bg-primary/40 animate-float-delayed" />
    <div className="absolute bottom-40 left-1/4 w-2.5 h-2.5 rounded-full bg-[hsl(var(--glow-blue))] opacity-40 animate-float" />

    <div className="max-w-3xl mx-auto text-center relative z-10">
      <div className="inline-block mb-6 animate-fade-up">
        <span className="px-4 py-1.5 rounded-full border border-primary/30 bg-primary/5 text-primary font-mono text-xs tracking-widest uppercase">
          Hello, I'm
        </span>
      </div>
      <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold leading-tight mb-6 animate-fade-up animate-delay-100">
        Nidhi <span className="text-gradient">Dwivedi</span>
      </h1>
      <div className="flex items-center justify-center gap-3 mb-6 animate-fade-up animate-delay-200">
        <span className="h-px w-8 bg-primary/50" />
        <p className="text-lg md:text-xl text-foreground/80 font-medium">
          Python Developer &amp; Desktop Support Engineer
        </p>
        <span className="h-px w-8 bg-primary/50" />
      </div>
      <p className="text-muted-foreground max-w-lg mx-auto mb-10 animate-fade-up animate-delay-300 leading-relaxed">
        Building efficient automation solutions and delivering reliable IT support.
        Passionate about solving complex problems with clean, maintainable code.
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up animate-delay-400">
        <a
          href="#projects"
          className="group inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-primary text-primary-foreground font-semibold hover:shadow-[0_0_30px_hsl(var(--primary)/0.4)] transition-all duration-300 hover:scale-105"
        >
          View My Work
          <ArrowDown size={16} className="group-hover:translate-y-0.5 transition-transform -rotate-90" />
        </a>
        <a
          href="#contact"
          className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full border border-primary/30 text-foreground font-semibold hover:bg-primary/10 hover:border-primary/50 transition-all duration-300"
        >
          Get in Touch
        </a>
      </div>
      <a
        href="#about"
        className="inline-block mt-20 text-muted-foreground hover:text-primary transition-colors animate-bounce"
        aria-label="Scroll down"
      >
        <div className="w-6 h-10 rounded-full border-2 border-current flex justify-center pt-2">
          <div className="w-1 h-2 rounded-full bg-current animate-scroll-indicator" />
        </div>
      </a>
    </div>
  </section>
);

export default HeroSection;
