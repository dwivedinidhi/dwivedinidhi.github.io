import { Briefcase, CheckCircle } from "lucide-react";
import { useInView } from "../hooks/useInView";

const ExperienceSection = () => {
  const { ref, inView } = useInView();

  const responsibilities = [
    "Provided first-level and second-level desktop support for 200+ users across Windows and Linux environments",
    "Diagnosed and resolved hardware, software, and network issues with a 95% first-call resolution rate",
    "Developed Python automation scripts to streamline repetitive IT tasks such as user provisioning and log analysis",
    "Managed Active Directory accounts, group policies, and system configurations",
    "Documented troubleshooting procedures and maintained an internal knowledge base",
  ];

  return (
    <section id="experience" className="section-padding relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(hsl(var(--primary)) 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

      <div ref={ref} className="max-w-3xl mx-auto relative z-10">
        <h2 className={`text-3xl md:text-4xl font-bold mb-2 text-center transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          Work <span className="text-gradient">Experience</span>
        </h2>
        <p className={`text-muted-foreground text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          Where I've contributed
        </p>

        <div className={`relative bg-card/80 backdrop-blur-sm border border-border rounded-2xl p-8 transition-all duration-700 hover:border-primary/30 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {/* Accent line */}
          <div className="absolute left-0 top-8 bottom-8 w-1 bg-gradient-to-b from-primary to-[hsl(var(--glow-blue))] rounded-full" />

          <div className="flex items-start gap-4 mb-8 pl-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-[hsl(var(--glow-blue)/0.1)] flex items-center justify-center shrink-0">
              <Briefcase className="text-primary" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold">Desktop Support Engineer</h3>
              <p className="text-primary text-sm font-medium">IT Support · Full-time</p>
            </div>
          </div>
          <ul className="space-y-4 pl-4">
            {responsibilities.map((r, i) => (
              <li
                key={i}
                className={`flex items-start gap-3 text-muted-foreground text-sm leading-relaxed transition-all duration-500 ${
                  inView ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
                }`}
                style={{ transitionDelay: `${300 + i * 100}ms` }}
              >
                <CheckCircle size={16} className="text-primary mt-0.5 shrink-0" />
                {r}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
